"""API Atlas — a command-line HTTP API explorer built with Python's standard library."""

from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any


@dataclass
class ApiResponse:
    url: str
    status: int
    headers: dict[str, str]
    body: Any
    elapsed_ms: float


class ApiError(RuntimeError):
    """Raised when a request fails or returns an unsuccessful status."""


def build_url(base_url: str, params: dict[str, str] | None = None) -> str:
    """Append URL query parameters while preserving existing parameters."""
    if not params:
        return base_url
    parsed = urllib.parse.urlsplit(base_url)
    existing = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query = urllib.parse.urlencode(existing + list(params.items()))
    return urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, parsed.path, query, parsed.fragment)
    )


def request_api(
    url: str,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    payload: Any = None,
    timeout: float = 10.0,
) -> ApiResponse:
    """Send an HTTP request and decode JSON responses when possible."""
    import time

    method = method.upper()
    if not url.startswith(("http://", "https://")):
        raise ValueError("URL must start with http:// or https://")
    if timeout <= 0:
        raise ValueError("timeout must be greater than zero")

    request_headers = {"Accept": "application/json", "User-Agent": "API-Atlas/1.0"}
    if headers:
        request_headers.update(headers)

    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        request_headers.setdefault("Content-Type", "application/json")

    req = urllib.request.Request(url, data=data, headers=request_headers, method=method)
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read()
            status = response.status
            response_headers = dict(response.headers.items())
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        detail = raw.decode("utf-8", errors="replace")
        raise ApiError(f"HTTP {exc.code} {exc.reason}: {detail[:300]}") from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise ApiError(f"Request failed: {getattr(exc, 'reason', exc)}") from exc

    elapsed = (time.perf_counter() - start) * 1000
    decoded = raw.decode("utf-8", errors="replace")
    content_type = next(
        (v for k, v in response_headers.items() if k.lower() == "content-type"), ""
    )
    if "json" in content_type.lower():
        try:
            body = json.loads(decoded) if decoded else None
        except json.JSONDecodeError:
            body = decoded
    else:
        body = decoded

    return ApiResponse(url, status, response_headers, body, round(elapsed, 2))


def pretty_print(result: ApiResponse, show_headers: bool = False) -> None:
    print(f"\n{result.status} OK  |  {result.elapsed_ms:.2f} ms")
    print(f"URL: {result.url}")
    if show_headers:
        print("\nResponse headers:")
        for key, value in sorted(result.headers.items()):
            print(f"  {key}: {value}")
    print("\nResponse body:")
    print(json.dumps(result.body, indent=2, ensure_ascii=False) if not isinstance(result.body, str)
          else result.body[:6000])


def save_response(result: ApiResponse, path: str) -> None:
    """Save response metadata and body as a JSON document."""
    output = {
        "url": result.url,
        "status": result.status,
        "elapsed_ms": result.elapsed_ms,
        "headers": result.headers,
        "body": result.body,
    }
    with open(path, "w", encoding="utf-8") as file:
        json.dump(output, file, indent=2, ensure_ascii=False)


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="API Atlas — inspect HTTP APIs from your terminal."
    )
    parser.add_argument("url", nargs="?", help="Full endpoint URL")
    parser.add_argument("--method", choices=["GET", "POST", "PUT", "PATCH", "DELETE"],
                        default="GET", help="HTTP method (default: GET)")
    parser.add_argument("--param", action="append", default=[], metavar="KEY=VALUE",
                        help="Query parameter; can be repeated")
    parser.add_argument("--header", action="append", default=[], metavar="KEY=VALUE",
                        help="Request header; can be repeated")
    parser.add_argument("--data", help="JSON payload for POST/PUT/PATCH")
    parser.add_argument("--timeout", type=float, default=10.0, help="Timeout in seconds")
    parser.add_argument("--show-headers", action="store_true", help="Print response headers")
    parser.add_argument("--save", metavar="FILE", help="Save response as JSON")
    parser.add_argument("--demo", action="store_true",
                        help="Use JSONPlaceholder demo endpoint /posts/1")
    return parser


def parse_key_value(values: list[str], flag: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in values:
        if "=" not in item:
            raise ValueError(f"{flag} expects KEY=VALUE, got: {item}")
        key, value = item.split("=", 1)
        if not key:
            raise ValueError(f"{flag} key cannot be empty")
        result[key] = value
    return result


def main(argv: list[str] | None = None) -> int:
    parser = make_parser()
    args = parser.parse_args(argv)
    url = args.url
    if args.demo:
        url = "https://jsonplaceholder.typicode.com/posts/1"
    if not url:
        parser.error("provide a URL or use --demo")

    try:
        params = parse_key_value(args.param, "--param")
        headers = parse_key_value(args.header, "--header")
        url = build_url(url, params)
        payload = json.loads(args.data) if args.data else None
        result = request_api(url, args.method, headers, payload, args.timeout)
        pretty_print(result, args.show_headers)
        if args.save:
            save_response(result, args.save)
            print(f"\nSaved response to {args.save}")
        return 0
    except (ValueError, ApiError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
