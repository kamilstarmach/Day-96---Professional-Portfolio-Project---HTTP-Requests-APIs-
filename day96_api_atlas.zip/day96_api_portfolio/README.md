# Day 96 — API Atlas
**100 Days of Code | Professional Portfolio Project — HTTP Requests & APIs**

API Atlas is a command-line HTTP API explorer written in Python. It makes requests to REST endpoints, supports query parameters and custom headers, sends JSON payloads, reports response timing, optionally prints response headers, and exports the result to JSON.

## Features
- GET, POST, PUT, PATCH, and DELETE methods
- Repeatable `--param KEY=VALUE` and `--header KEY=VALUE` options
- JSON request bodies and automatic JSON response decoding
- Request timeout and readable HTTP/network errors
- Response timing and optional response-header display
- Save response metadata and body to a JSON file
- Demo mode using JSONPlaceholder

## Requirements
- Python 3.10+
- No third-party packages required

## Quick start

```bash
python main.py --demo
```

Inspect a public endpoint:

```bash
python main.py "https://jsonplaceholder.typicode.com/posts" --param userId=1 --show-headers --save posts.json
```

Send JSON to a test endpoint:

```bash
python main.py "https://jsonplaceholder.typicode.com/posts" --method POST --data "{\"title\":\"API Atlas\",\"body\":\"Hello API\",\"userId\":1}"
```

Add a custom header:

```bash
python main.py "https://api.example.com/items" --header "Authorization=Bearer YOUR_TOKEN" --param limit=10
```

Use `python main.py --help` to see all options. Avoid placing real secrets in shell history; use environment variables or a secret manager for production workflows.

## Run tests

```bash
python -m unittest discover -s tests -v
```

The test suite uses mocked HTTP responses and does not require internet access.

## Project structure

```text
day96_api_portfolio/
├── main.py
├── requirements.txt
├── README.md
├── .gitignore
└── tests/
    └── test_api_atlas.py
```

## Skills demonstrated
HTTP methods, URL encoding, request headers, JSON serialization/deserialization, exception handling, CLI design with `argparse`, response timing, file export, and unit testing with mocks.
