import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import main


class FakeHeaders:
    def __init__(self, values):
        self.values = values
    def items(self):
        return self.values.items()


class FakeResponse:
    status = 200
    headers = FakeHeaders({"Content-Type": "application/json; charset=utf-8"})
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def read(self):
        return b'{"hello":"world"}'


class ApiAtlasTests(unittest.TestCase):
    def test_build_url_adds_and_preserves_query(self):
        self.assertEqual(
            main.build_url("https://example.com/items?page=1", {"q": "red shoes"}),
            "https://example.com/items?page=1&q=red+shoes",
        )

    def test_parse_key_value(self):
        self.assertEqual(main.parse_key_value(["X-Test=hello=there"], "--header"),
                         {"X-Test": "hello=there"})

    def test_parse_key_value_rejects_missing_equals(self):
        with self.assertRaises(ValueError):
            main.parse_key_value(["invalid"], "--header")

    def test_request_api_decodes_json(self):
        with patch("main.urllib.request.urlopen", return_value=FakeResponse()):
            result = main.request_api("https://example.com")
        self.assertEqual(result.status, 200)
        self.assertEqual(result.body, {"hello": "world"})

    def test_request_api_rejects_invalid_scheme(self):
        with self.assertRaises(ValueError):
            main.request_api("file:///etc/passwd")

    def test_request_api_rejects_nonpositive_timeout(self):
        with self.assertRaises(ValueError):
            main.request_api("https://example.com", timeout=0)

    def test_save_response(self):
        result = main.ApiResponse("https://example.com", 200, {}, {"ok": True}, 12.3)
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "result.json"
            main.save_response(result, str(target))
            data = json.loads(target.read_text(encoding="utf-8"))
        self.assertEqual(data["body"], {"ok": True})
        self.assertEqual(data["elapsed_ms"], 12.3)


if __name__ == "__main__":
    unittest.main()
